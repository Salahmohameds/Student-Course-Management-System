SELECT 
    AVG(student_count) AS average_enrollments,
    MIN(student_count) AS min_enrollments,
    MAX(student_count) AS max_enrollments
FROM (
    SELECT 
        course_id, COUNT(student_id) AS student_count
    FROM 
        Enrollments
    GROUP BY 
        course_id
) AS enrollments_per_course;
