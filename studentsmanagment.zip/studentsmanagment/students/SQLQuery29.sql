SELECT first_name, last_name, 
dbo.Calculate_Age(date_of_birth) AS age
FROM student;
