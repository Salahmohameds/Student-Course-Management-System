SELECT 
    S.first_name, S.last_name
FROM 
    Students S
WHERE 
    S.student_id IN (
        SELECT 
            E.student_id
        FROM 
            Enrollments E
        GROUP BY 
            E.student_id
        HAVING 
            COUNT(E.course_id) > 1
    );
