SELECT 
    first_name, 
    last_name,
    CASE 
        WHEN DATEDIFF(YEAR, date_of_birth, GETDATE()) < 20 THEN 'Teenager'
        WHEN DATEDIFF(YEAR, date_of_birth, GETDATE()) BETWEEN 20 AND 25 THEN 'Young Adult'
        ELSE 'Adult'
    END AS age_group
FROM 
    Students;
