CREATE TABLE Students (
    student_id INT PRIMARY KEY IDENTITY(1,1),
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100),
    date_of_birth DATE
);


INSERT INTO Students (first_name, last_name, email, date_of_birth) VALUES
('Ahmed', 'El-Sayed', 'ahmed.elsayed@gmail.com', '2000-01-15'),
('Mona', 'Hassan', 'mona.hassan@gmail.com', '1999-02-20'),
('Mohamed', 'Ali', 'mohamed.ali@gmail.com', '2001-03-10'),
('Sara', 'Fathy', 'sara.fathy@gmail.com', '1998-04-25'),
('Omar', 'Khaled', 'omar.khaled@gmail.com', '2000-05-30'),
('Laila', 'Nabil', 'laila.nabil@gmail.com', '1999-06-15'),
('Hassan', 'Gamal', 'hassan.gamal@gmail.com', '2001-07-20'),
('Dina', 'Youssef', 'dina.youssef@gmail.com', '1998-08-05'),
('Tamer', 'Khalil', 'tamer.khalil@gmail.com', '1999-09-25'),
('Nadia', 'Farouk', 'nadia.farouk@gmail.com', '2000-10-10'),
('Yasser', 'Adel', 'yasser.adel@gmail.com', '2001-11-15'),
('Fatma', 'Saleh', 'fatma.saleh@gmail.com', '1998-12-05'),
('Khaled', 'Mohsen', 'khaled.mohsen@gmail.com', '2002-03-15');


CREATE TABLE Instructors (
    instructor_id INT PRIMARY KEY IDENTITY(1,1),
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    email VARCHAR(100)
);

INSERT INTO Instructors (first_name, last_name, email) VALUES
('Hesham', 'Mansour', 'hesham.mansour@gmail.com'),
('Amina', 'Zaki', 'amina.zaki@gmail.com'),
('Karim', 'Mostafa', 'karim.mostafa@gmail.com'),
('Rania', 'Adel', 'rania.adel@gmail.com'),
('Tarek', 'Nassar', 'tarek.nassar@gmail.com');

CREATE TABLE Courses (
    course_id INT PRIMARY KEY IDENTITY(1,1),
    course_name VARCHAR(100),
    course_description TEXT,
    instructor_id INT,
    FOREIGN KEY (instructor_id) REFERENCES Instructors(instructor_id)
);



INSERT INTO Courses (course_name, course_description, instructor_id) VALUES
('Introduction to Programming', 'Basic concepts of programming using Python.', 1),     -- Hesham Mansour
('Data Structures', 'Understanding and implementing various data structures.', 2),    -- Amina Zaki
('Database Systems', 'Introduction to database design and SQL.', 3),                  -- Karim Mostafa
('Computer Networks', 'Fundamentals of computer networking and protocols.', 4),       -- Rania Adel
('Operating Systems', 'Concepts of operating systems and process management.', 5),    -- Tarek Nassar
('Advanced Algorithms', 'In-depth study of advanced algorithmic techniques.', 3);

CREATE TABLE Enrollments (
    enrollment_id INT PRIMARY KEY IDENTITY(1,1),
    student_id INT,
    course_id INT,
    enrollment_date DATE,
    FOREIGN KEY (student_id) REFERENCES Students(student_id),
    FOREIGN KEY (course_id) REFERENCES Courses(course_id)
);

INSERT INTO Enrollments (student_id, course_id, enrollment_date) VALUES
(1, 1, '2024-01-10'),  
(2, 2, '2024-01-12'),  
(3, 4, '2024-01-14'), 
(4, 4, '2024-01-16'),  
(5, 5, '2024-01-18'), 
(6, 1, '2024-01-20'),  
(7, 2, '2024-01-22'), 
(8, 3, '2024-01-24'), 
(9, 4, '2024-01-26'),  
(10, 5, '2024-01-28'), 
(11, 1, '2024-01-30'), 
(12, 2, '2024-02-01'), 
(1, 3, '2024-02-03'), 
(2, 4, '2024-02-05'),  
(3, 5, '2024-02-07'), 
(4, 1, '2024-02-10'),  
(5, 2, '2024-02-12'),  
(6, 3, '2024-02-14'), 
(7, 4, '2024-02-16'),  
(8, 5, '2024-02-18'),  
(9, 1, '2024-02-20'),  
(10, 2, '2024-02-22'), 
(11, 3, '2024-02-24'),
(12, 4, '2024-02-26'); 

