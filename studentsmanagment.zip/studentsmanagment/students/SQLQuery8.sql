UPDATE 
    Students
SET 
    email = 'new.email@example.com'
WHERE 
    student_id = 1;
