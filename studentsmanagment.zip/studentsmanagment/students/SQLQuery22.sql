SELECT COUNT(*) AS total_students FROM Students;
