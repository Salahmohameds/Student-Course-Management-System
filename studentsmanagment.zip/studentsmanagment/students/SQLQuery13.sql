SELECT 
    S.first_name, S.last_name, C.course_name
FROM 
    Students S
LEFT JOIN 
    Enrollments E ON S.student_id = E.student_id
LEFT JOIN 
    Courses C ON E.course_id = C.course_id;
