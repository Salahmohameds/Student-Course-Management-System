SELECT 
    TOP 1 C.course_name, COUNT(E.enrollment_id) AS enrollment_count
FROM 
    Enrollments E
JOIN 
    Courses C ON E.course_id = C.course_id
GROUP BY 
    C.course_name
ORDER BY 
    COUNT(E.enrollment_id) DESC;
