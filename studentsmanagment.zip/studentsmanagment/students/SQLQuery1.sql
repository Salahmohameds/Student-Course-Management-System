CREATE DATABASE StudentCourseManagement;
USE StudentCourseManagement;

