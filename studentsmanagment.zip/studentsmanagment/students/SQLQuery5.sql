SELECT 
    E.enrollment_id, 
    S.first_name + ' ' + S.last_name AS student_name,
    C.course_name,
    E.enrollment_date
FROM 
    Enrollments E
JOIN 
    Students S ON E.student_id = S.student_id
JOIN 
    Courses C ON E.course_id = C.course_id;
