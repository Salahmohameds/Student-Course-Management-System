-- Single-line comment: This query retrieves all students with their age and age category
SELECT 
    first_name AS FirstName, -- First name of the student
    last_name AS LastName,   -- Last name of the student
    dbo.CalculateAge(date_of_birth) AS Age,
    CASE 
        WHEN dbo.CalculateAge(date_of_birth) < 20 THEN 'Young'  -- Age less than 20
        WHEN dbo.CalculateAge(date_of_birth) BETWEEN 20 AND 30 THEN 'Adult'  -- Age between 20 and 30
        ELSE 'Senior'  -- Age greater than 30
    END AS AgeCategory
FROM student;

-- Multi-line comment: The following query finds courses with at least one student enrolled
/*
This query selects all course IDs and names from the 'course' table
where there is at least one enrollment for that course.
*/