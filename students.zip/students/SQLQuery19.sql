SELECT 
    first_name, last_name
FROM 
    Students
WHERE 
    date_of_birth < '2000-01-01'
UNION
SELECT 
    first_name, last_name
FROM 
    Instructors
WHERE 
    last_name LIKE 'A%';
