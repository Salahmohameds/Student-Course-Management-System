SELECT 
    S.first_name, S.last_name
FROM 
    Students S
LEFT JOIN 
    Enrollments E ON S.student_id = E.student_id
WHERE 
    E.enrollment_id IS NULL;
