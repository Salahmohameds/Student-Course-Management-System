SELECT * FROM Courses;
