-- Single-line comment: This query retrieves all students 
SELECT COUNT(*) AS total_students FROM Students;
-- Multi-line comment: This query retrieves all students 
/*
This query retrieves all students 
*/