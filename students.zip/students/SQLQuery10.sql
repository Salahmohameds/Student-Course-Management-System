SELECT 
    AVG(DATEDIFF(YEAR, date_of_birth, GETDATE())) AS average_age
FROM 
    Students;
