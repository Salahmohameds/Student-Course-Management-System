SELECT 
    I.first_name, I.last_name, C.course_name
FROM 
    Instructors I
LEFT JOIN 
    Courses C ON I.instructor_id = C.instructor_id;
