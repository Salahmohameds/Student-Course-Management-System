SELECT 
    TOP 3 S.first_name, S.last_name, COUNT(E.enrollment_id) AS enrollment_count
FROM 
    Students S
JOIN 
    Enrollments E ON S.student_id = E.student_id
GROUP BY 
    S.first_name, S.last_name
ORDER BY 
    COUNT(E.enrollment_id) DESC;
