SELECT 
    S.first_name AS 'Student First Name', 
    S.last_name AS 'Student Last Name', 
    C.course_name AS 'Course Name'
FROM 
    Students S
JOIN 
    Enrollments E ON S.student_id = E.student_id
JOIN 
    Courses C ON E.course_id = C.course_id;
