SELECT 
    course_name
FROM 
    Courses C
WHERE 
    EXISTS (
        SELECT 
            1
        FROM 
            Enrollments E
        WHERE 
            E.course_id = C.course_id
    );
