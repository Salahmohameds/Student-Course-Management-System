SELECT 
    C.course_name, I.first_name, I.last_name
FROM 
    Courses C
JOIN 
    Instructors I ON C.instructor_id = I.instructor_id
WHERE 
    I.first_name = 'Karim' AND I.last_name = 'Mostafa';
