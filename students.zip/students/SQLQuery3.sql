SELECT * FROM Students;
