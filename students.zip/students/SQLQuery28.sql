EXEC Add_Student 
    @first_name = 'Donia', 
    @last_name = 'Mohamed', 
    @email = 'donia.mohamed@example.com', 
    @date_of_birth = '2000-01-01';

SELECT * FROM Students;

