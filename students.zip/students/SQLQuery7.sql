SELECT 
    C.course_name, COUNT(E.student_id) AS student_count
FROM 
    Enrollments E
JOIN 
    Courses C ON E.course_id = C.course_id
GROUP BY 
    C.course_name
HAVING 
    COUNT(E.student_id) > 5;
